import b1 from "../assets/b1.jpg";
import b2 from "../assets/b2.jpg";
import b3 from "../assets/b3.jpg";
import Reveal from "./Reveal";

const POSTS = [
  { img: b1, alt: "Pink gerbera flower beside a cup of tea and a macaron" },
  { img: b2, alt: "Three succulents in white pots on a minimal white desk" },
  { img: b3, alt: "Pink tulips on a clean white desk with a phone and notepad" },
];

export default function Blog() {
  return (
    <section aria-labelledby="blog-title" className="pb-[70px] pt-[20px] lg:pb-[100px] lg:pt-[30px]">
      <div className="mx-auto max-w-[1200px] px-[15px]">
        <Reveal className="mb-[40px] flex items-center justify-center gap-5 lg:mb-[55px] lg:gap-[22px]">
          <span className="h-[2px] w-[50px] bg-ink sm:w-[80px]" aria-hidden="true" />
          <h2 id="blog-title" className="text-[24px] font-semibold uppercase text-ink lg:text-[30px]">
            Our Blog
          </h2>
          <span className="h-[2px] w-[50px] bg-ink sm:w-[80px]" aria-hidden="true" />
        </Reveal>

        <div className="grid gap-10 sm:grid-cols-2 sm:gap-[30px] lg:grid-cols-3">
          {POSTS.map((post, i) => (
            <Reveal as="article" key={i} delay={i * 130} className={`group ${i === 2 ? "sm:col-span-2 sm:mx-auto sm:w-1/2 sm:px-[15px] lg:col-span-1 lg:w-auto lg:px-0" : ""}`}>
              <a href="#" className="block">
                <div className="relative aspect-[370/270] overflow-hidden">
                  <img
                    src={post.img}
                    alt={post.alt}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-110"
                  />
                  <span className="absolute left-[10px] top-[10px] bg-[#e959f2] px-[10px] py-[2px] text-[11px] font-medium text-white lg:left-[15px] lg:top-[15px] lg:text-[12px]">
                    Lifestyle
                  </span>
                </div>
                <div className="relative mx-[18px] -mt-[62px] bg-white px-4 pb-1 pt-4 text-center lg:mx-[35px] lg:-mt-[65px]">
                  <h3 className="text-[16px] font-medium leading-[1.6] text-ink transition-colors duration-300 group-hover:text-accent lg:text-[20px] lg:leading-[1.55]">
                    Lorem ipsum dolor sit
                    <br />
                    amet consec.
                  </h3>
                </div>
              </a>
              <p className="mt-2 text-center text-[13px] italic text-muted lg:text-[14px]">
                By{" "}
                <a href="#" className="transition-colors hover:text-accent">
                  Shop Admin
                </a>
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
